# Behavior Application Initialization
