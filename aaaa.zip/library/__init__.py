# Library Application Initialization
